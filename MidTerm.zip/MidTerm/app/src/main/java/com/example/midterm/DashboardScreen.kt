package com.example.midterm

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Student(
    val id: String,
    val name: String,
    val phone: String,
    val address: String
)

@Composable
fun DashboardScreen(onRegisterClick: () -> Unit) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("Student Dashboard", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onRegisterClick) {
            Text("Register Student")
        }
        Spacer(modifier = Modifier.height(16.dp))
        LazyColumn {
            items(AddStudentScreen.students) { student ->
                Card(modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("ID: ${student.id}")
                        Text("Name: ${student.name}")
                        Text("Phone: ${student.phone}")
                        Text("Address: ${student.address}")
                    }
                }
            }
        }
    }
}
