package com.example.midterm

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.example.midterm.LoginScreen
import com.example.midterm.DashboardScreen
import com.example.midterm.AddStudentScreen
import com.example.midterm.ui.theme.MidTermTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MidTermTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    var currentScreen by remember { mutableStateOf("login") }

                    when (currentScreen) {
                        "login" -> LoginScreen(onLoginSuccess = {
                            currentScreen = "dashboard"
                        })
                        "dashboard" -> DashboardScreen(
                            onRegisterClick = { currentScreen = "add" }
                        )
                        "add" -> AddStudentScreen(
                            onSave = { currentScreen = "dashboard" },
                            onCancel = { currentScreen = "dashboard" }
                        )
                    }
                }
            }
        }
    }
}
